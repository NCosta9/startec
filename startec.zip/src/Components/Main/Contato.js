import SendOrcamento from "../../Utils/SendOrcamento";
import { useForm } from "react-hook-form";
import emailjs from "@emailjs/browser";
import { useNavigate } from "react-router-dom";



export default function Contato() {

  const navigate = useNavigate();

  const { register, handleSubmit, getValues } = useForm();

  //Envia todos os dados do formulario por meio de uma url do whatsapp
  const formValues = getValues();
  const nome = `${formValues.NOME}`
  const telefone = `${formValues.TELEFONE}`
  const email = `${formValues.EMAIL}`
  const mensagem = `${formValues.MENSAGEM}`

  //Dados para envio via Email
  const assunto = "Orçamento Startec";
  const cabecalho = "Ja recebemos as informações para seu " + assunto + " ,dentro de alguns instantes entraremos em contato com mais informações. Verifique abaixo se as informações que recebemos estão corretas: ";


  function sendWhatsapp(e) {
    e.preventDefault();

    const userData = `
  Eu ${nome}, gostaria e realizar um ${assunto}.

  Telefone: ${telefone}
  Email: ${email}
  Mensagem: ${mensagem}

 
`;

    console.log(userData);

    const templateParams = {
      assunto: assunto,
      message: userData,
    };
    const templateParamsCliente = {
      assunto: assunto,
      cabecalho: cabecalho,
      message: userData,
      cliente: nome,
      cliente_mail: email,
    };

    console.log(templateParams);

    emailjs
      .send(
        "service_au350rb",
        "template_oh38moq",
        templateParams,
        "8Lm_V9EVCD5qu2Vqk"
      ).then(
        (response) => {
          // console.log("DADOS ENVIADO COM SUCCESSO!", response.status, response.text);   
          navigate("/sucesso")

        },
        (error) => {
          //console.log("OPS!! NÃO FOI POSSIVEL RECEBER OS DADOS...", error);
          navigate("/error")
        }
      );

    emailjs
      .send(
        "service_au350rb",
        "template_xqy15f2",
        templateParamsCliente,
        "8Lm_V9EVCD5qu2Vqk"
      );


    let url = "https://api.whatsapp.com/send?phone=556120993434&text=";
    let end_url = `
  ${url}Eu ${nome} solicitei pelo site um ${assunto}.
  ${mensagem}

  Dados para contato: 
  ${email}
  ${telefone}
  `;
    window.open(end_url)
  }






  return (
    <>
      <section id="contact" class="contact">
        <div class="container">

          <div class="section-title">
            <span>Contato</span>
            <h2>Contato</h2>
            <p>Fale conosco em um dos canais de atendimento ao cliente abaixo para solicitar seu orçamento</p>
          </div>

          <div class="row" data-aos="fade-up">
            <div class="col-lg-6">
              <div class="info-box mb-4">
                <i class="bx bx-map">
                  <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 24 24"><path fill="#cc1616" d="M12 14c2.206 0 4-1.794 4-4s-1.794-4-4-4s-4 1.794-4 4s1.794 4 4 4zm0-6c1.103 0 2 .897 2 2s-.897 2-2 2s-2-.897-2-2s.897-2 2-2z" /><path fill="#cc1616" d="M11.42 21.814a.998.998 0 0 0 1.16 0C12.884 21.599 20.029 16.44 20 10c0-4.411-3.589-8-8-8S4 5.589 4 9.995c-.029 6.445 7.116 11.604 7.42 11.819zM12 4c3.309 0 6 2.691 6 6.005c.021 4.438-4.388 8.423-6 9.73c-1.611-1.308-6.021-5.294-6-9.735c0-3.309 2.691-6 6-6z" /></svg>
                </i>
                <h3>Endereço</h3>
                <p>SH Arniqueiras Col. Agrícola Arniqueira - Taguatinga, Brasília - DF</p>
              </div>
            </div>

            <div class="col-lg-4 col-md-6">
              <div class="info-box  mb-4">
                <i class="bx bx-envelope">
                  <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 24 24"><path fill="#cc1616" d="M20 4H4c-1.103 0-2 .897-2 2v12c0 1.103.897 2 2 2h16c1.103 0 2-.897 2-2V6c0-1.103-.897-2-2-2zm0 2v.511l-8 6.223l-8-6.222V6h16zM4 18V9.044l7.386 5.745a.994.994 0 0 0 1.228 0L20 9.044L20.002 18H4z" /></svg>
                </i>
                <h3>Email</h3>
                <p>atendimento@startecmontagem.com.br</p>
              </div>
            </div>

            <div class="col-lg-2 col-md-6">
              <div class="info-box  mb-4">
                <i class="bx bx-phone-call">
                  <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 24 24"><path fill="currentColor" d="M16.57 22a2 2 0 0 0 1.43-.59l2.71-2.71a1 1 0 0 0 0-1.41l-4-4a1 1 0 0 0-1.41 0l-1.6 1.59a7.55 7.55 0 0 1-3-1.59a7.62 7.62 0 0 1-1.59-3l1.59-1.6a1 1 0 0 0 0-1.41l-4-4a1 1 0 0 0-1.41 0L2.59 6A2 2 0 0 0 2 7.43A15.28 15.28 0 0 0 6.3 17.7A15.28 15.28 0 0 0 16.57 22zM6 5.41L8.59 8L7.3 9.29a1 1 0 0 0-.3.91a10.12 10.12 0 0 0 2.3 4.5a10.08 10.08 0 0 0 4.5 2.3a1 1 0 0 0 .91-.27L16 15.41L18.59 18l-2 2a13.28 13.28 0 0 1-8.87-3.71A13.28 13.28 0 0 1 4 7.41zM20 11h2a8.81 8.81 0 0 0-9-9v2a6.77 6.77 0 0 1 7 7z" /><path fill="#cc1616" d="M13 8c2.1 0 3 .9 3 3h2c0-3.22-1.78-5-5-5z" /></svg>
                </i>
                <h3>Telefone</h3>
                <p>(61) 98524-0010</p>
              </div>
            </div>

          </div>

          <div class="row" data-aos="fade-up">

            <div class="col-lg-6 ">
              <iframe class="localization mb-4 mb-lg-0" src="https://www.google.com/maps/embed?pb=!1m17!1m12!1m3!1d3838.1197851871484!2d-48.02054712554488!3d-15.850300424332847!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m2!1m1!2zMTXCsDUxJzAxLjEiUyA0OMKwMDEnMDQuNyJX!5e0!3m2!1spt-BR!2sbr!4v1698763996022!5m2!1spt-BR!2sbr" width="600" height="450" frameborder="0" allowfullscreen loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>

            <div class="col-lg-6">
              <form method="post" role="form" class="php-email-form">
                <div class="row">
                  <div class="col-md-6 form-group">
                    <input type="text" name="name" class="form-control" id="name" placeholder="Digite seu nome..." {...register("NOME", { required: true })} required />
                  </div>
                  <div class="col-md-6 form-group mt-3 mt-md-0">
                    <input type="tel" class="form-control" name="telefone" id="subject" placeholder="Digite seu Telefone..."{...register("TELEFONE", { required: true })} required />
                  </div>
                  <div class="form-group mt-3">
                    <input type="email" class="form-control" name="email" id="email" placeholder="Digite seu email..." {...register("EMAIL", { required: true })} required />
                  </div>
                </div>

                <div class="form-group mt-3">
                  <textarea class="form-control" name="message" rows="5" placeholder="Escreva uma mensagem..." {...register("MENSAGEM", { required: true })} required></textarea>
                </div>

                <div class="text-center">
                  <button
                  class="mt-2"
                    type="Submit"
                    onClick={handleSubmit(sendWhatsapp)}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="currentColor" d="M19.05 4.91A9.816 9.816 0 0 0 12.04 2c-5.46 0-9.91 4.45-9.91 9.91c0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38c1.45.79 3.08 1.21 4.74 1.21c5.46 0 9.91-4.45 9.91-9.91c0-2.65-1.03-5.14-2.9-7.01zm-7.01 15.24c-1.48 0-2.93-.4-4.2-1.15l-.3-.18l-3.12.82l.83-3.04l-.2-.31a8.264 8.264 0 0 1-1.26-4.38c0-4.54 3.7-8.24 8.24-8.24c2.2 0 4.27.86 5.82 2.42a8.183 8.183 0 0 1 2.41 5.83c.02 4.54-3.68 8.23-8.22 8.23zm4.52-6.16c-.25-.12-1.47-.72-1.69-.81c-.23-.08-.39-.12-.56.12c-.17.25-.64.81-.78.97c-.14.17-.29.19-.54.06c-.25-.12-1.05-.39-1.99-1.23c-.74-.66-1.23-1.47-1.38-1.72c-.14-.25-.02-.38.11-.51c.11-.11.25-.29.37-.43s.17-.25.25-.41c.08-.17.04-.31-.02-.43s-.56-1.34-.76-1.84c-.2-.48-.41-.42-.56-.43h-.48c-.17 0-.43.06-.66.31c-.22.25-.86.85-.86 2.07c0 1.22.89 2.4 1.01 2.56c.12.17 1.75 2.67 4.23 3.74c.59.26 1.05.41 1.41.52c.59.19 1.13.16 1.56.1c.48-.07 1.47-.6 1.67-1.18c.21-.58.21-1.07.14-1.18s-.22-.16-.47-.28z" /></svg>
                    Enviar Mensagem
                  </button>
                </div>
              </form>
            </div>

          </div>

        </div>
      </section>
    </>
  )
}